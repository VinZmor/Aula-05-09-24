<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Slice_php</title>
</head>
<body>
    <?php
    
    // Neste exemplo, a função array_splice() é ultilizado para remover um elemento de um array a partir de uma posição específica.
    

    $cidades = array("São Paulo", "Belo Horizonte", "Salvador");
    
    // Remove o elemento "Belo Horizonte" do array.

    array_slice($cidades, 2, 1);

    // Imprimindo o array atualizado

    print_r($cidades);
    
    ?>
</body>
</html>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cripitografia</title>
</head>
<body>
    
<?php

// Palavra original

$Nome = "Zezília";

// Codificando a string em Base64
$Codificar = base64_encode($Nome);

// Exibir palavra codificado
echo "Codificando em Base64: " . $Codificar . "\n";

// Decodificar a string de Base64
$Decodificar = base64_decode($Codificar);

// Exibir a string decodificar
echo "Decodificando em Base64: " . $Decodificar . "\n";

?>
</body>
</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    
</head>

<body>
    <form action="meio.php" method="post">
        <h1>Login</h1>

        <div>
            <label>
                Nome:
            </label>
            <input type="text" name="campo_nome">
        </div>
        <br>
        <div>
            <label>
                Senha:
            </label>
            <input type="password" name="campo_senha">
        </div>
        <br>

        <input type="submit">
    </form>
</body>

</html>
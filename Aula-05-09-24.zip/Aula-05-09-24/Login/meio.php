<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado do Login</title>

</head>

<body>
    <?php

    $nome = $_POST["campo_nome"];
    $senha = $_POST["campo_senha"];

    if ($nome == '' || $senha == '') {
        echo "<h1 style='color: red;'> Algo deu Errado </h1>";
        echo "<p> Sua senha ou nome não foram preenchidos";
    } else {
        $senha_codificada = md5($senha);

        echo "<h1 style='color: #00ff11'>Login bem Sucedido</h1>";
        echo "<h2> Informações sobre o Login: <h2>";
        echo "<p>Nome: " . ($nome) . "</p>";
        echo "<p>Data de Cadastro: " . date("d/m/Y");
        echo "<p>Horario de Cadastro: " . date("H:i");
    }
    ?>
    <form action="fim.php" method="post">
        <input type="submit">
</body>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bem Vindo</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        h1 {
            color: #333;
        }
        p {
            margin: 5px 0;
        }
        .icon {
            width: 16px;
            height: 16px;
            margin-right: 5px;
            vertical-align: middle;
        }
    </style>
</head>

<body>
    <?php
    $amigos = array("Matheus", "Larissa", "Zezília", "José");
    $parentes = array("Rafael", "Luis", "Isack", "Mario");

    // Contagem de amigos
    $numero_de_amigos = count($amigos);

    // Remove e retorna o primeiro amigo
    $primeiro_amigo = array_shift($amigos);

    // Reverte a ordem dos amigos restantes
    $amigos_revertidos = array_reverse($amigos);

    // Concatena os arrays de amigos e parentes
    $array_concatenado = array_merge($amigos, $parentes);

    // Exibe as informações
    echo "<h1> Bem Vindo ao Y </h1>";
    echo "<p><img class='icon' src='https://img.icons8.com/ios-filled/50/000000/friends.png'/> Número de Amigos: " . $numero_de_amigos . "</p>";
    echo "<p><img class='icon' src='https://img.icons8.com/ios-filled/50/000000/user.png'/> Primeiro Amigo Removido: " . $primeiro_amigo . "</p>";
    echo "<p><img class='icon' src='https://img.icons8.com/ios-filled/50/000000/sort-up.png'/> Amigos Revertidos: " . implode(", ", $amigos_revertidos) . "</p>";

    // Exibindo arrays concatenados
    echo "<p><img class='icon' src='https://img.icons8.com/ios-filled/50/000000/merge.png'/> Arrays concatenados:</p>";
    echo "<pre>";
    print_r($array_concatenado);
    echo "</pre>";

    // Extraindo uma parte do array concatenado
    $sub_array = array_slice($array_concatenado, 1, 3);
    echo "<p><img class='icon' src='https://img.icons8.com/ios-filled/50/000000/extract.png'/> Parte do array extraída:</p>";
    echo "<pre>";
    print_r($sub_array);
    echo "</pre>";

    // Adicionando um novo elemento no início do array de frutas
    
    array_unshift($amigos, "Isack");
    echo "<p><img class='icon' src='https://img.icons8.com/ios-filled/50/000000/user.png'/> Adicionando 'Isack' aos amigos:</p>";
    echo "<pre>";
    print_r($amigos);
    ?>
</body>

</html>
